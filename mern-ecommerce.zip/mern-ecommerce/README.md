# MERN E-commerce Mini App (Starter)
This repository contains a minimal MERN e-commerce starter project.

## Structure
- backend/ : Express + MongoDB backend (auth, products)
- frontend/: React frontend (simple UI: signup/login, products, admin add product)

## Quick start (local)
1. Backend:
   - cd backend
   - copy .env.example to .env and fill values (MONGO_URI, ACCESS_TOKEN_SECRET)
   - npm install
   - npm run dev

2. Frontend:
   - cd frontend
   - npm install
   - set REACT_APP_API if backend is not localhost:5000
   - npm start

## Notes
- This is a starter project. For production, add better error handling, validation, file upload, payments, and secure cookie-based refresh tokens.
