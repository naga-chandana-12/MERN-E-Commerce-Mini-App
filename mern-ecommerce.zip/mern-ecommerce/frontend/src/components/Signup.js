import React, { useState } from 'react';
import axios from 'axios';

export default function Signup({ onLogin, api }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${api}/api/auth/signup`, { name, email, password });
      onLogin(res.data.accessToken);
      alert('Signed up and logged in (token saved in memory). To add admin products, change role in DB to admin.');
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.msg || 'Error during signup');
    }
  };

  return (
    <form onSubmit={submit}>
      <input placeholder='Name' value={name} onChange={e=>setName(e.target.value)} /><br/>
      <input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder='Password' type='password' value={password} onChange={e=>setPassword(e.target.value)} /><br/>
      <button>Signup</button>
    </form>
  );
}
