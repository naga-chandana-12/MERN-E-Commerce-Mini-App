import React, { useState } from 'react';
import axios from 'axios';

export default function Login({ onLogin, api }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${api}/api/auth/login`, { email, password });
      onLogin(res.data.accessToken);
      alert('Logged in. Token stored in memory.');
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.msg || 'Login error');
    }
  };

  return (
    <form onSubmit={submit}>
      <input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder='Password' type='password' value={password} onChange={e=>setPassword(e.target.value)} /><br/>
      <button>Login</button>
    </form>
  );
}
