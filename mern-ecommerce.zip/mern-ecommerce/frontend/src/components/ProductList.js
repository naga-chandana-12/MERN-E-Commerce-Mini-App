import React from 'react';

export default function ProductList({ products }) {
  if (!products || products.length === 0) return <div>No products yet</div>;
  return (
    <div>
      {products.map(p => (
        <div key={p._id} style={{ border:'1px solid #ddd', padding:10, marginBottom:8 }}>
          <h3>{p.title} — ${p.price}</h3>
          <p>{p.description}</p>
          {p.image && <img src={p.image} alt='' style={{ maxWidth:200 }} />}
        </div>
      ))}
    </div>
  );
}
