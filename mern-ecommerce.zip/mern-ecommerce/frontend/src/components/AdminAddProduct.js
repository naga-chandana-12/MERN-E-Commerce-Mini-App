import React, { useState } from 'react';
import axios from 'axios';

export default function AdminAddProduct({ api, token, onAdded }) {
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [price, setPrice] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!token) return alert('You must login as admin (token required). Set role=admin in DB for your user.');
    try {
      const res = await axios.post(`${api}/api/products`, { title, description: desc, price: Number(price) }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTitle(''); setDesc(''); setPrice('');
      onAdded();
      alert('Product added');
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.msg || 'Error adding product');
    }
  };

  return (
    <form onSubmit={submit}>
      <input placeholder='Title' value={title} onChange={e=>setTitle(e.target.value)} /><br/>
      <input placeholder='Description' value={desc} onChange={e=>setDesc(e.target.value)} /><br/>
      <input placeholder='Price' value={price} onChange={e=>setPrice(e.target.value)} /><br/>
      <button>Add Product (admin)</button>
    </form>
  );
}
