import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Signup from './components/Signup';
import Login from './components/Login';
import ProductList from './components/ProductList';
import AdminAddProduct from './components/AdminAddProduct';

const API = process.env.REACT_APP_API || 'http://localhost:5000';

function App() {
  const [token, setToken] = useState(null);
  const [products, setProducts] = useState([]);

  const fetchProducts = async () => {
    try {
      const res = await axios.get(`${API}/api/products`);
      setProducts(res.data);
    } catch (err) { console.error(err); }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>MERN E-commerce (Mini)</h1>
      <div style={{ display:'flex', gap:20 }}>
        <div style={{ flex:1 }}>
          <h2>Auth</h2>
          <Signup onLogin={setToken} api={API} />
          <Login onLogin={setToken} api={API} />
        </div>
        <div style={{ flex:2 }}>
          <h2>Products</h2>
          <ProductList products={products} />
        </div>
        <div style={{ flex:1 }}>
          <h2>Admin</h2>
          <AdminAddProduct api={API} token={token} onAdded={fetchProducts} />
        </div>
      </div>
    </div>
  );
}

export default App;
