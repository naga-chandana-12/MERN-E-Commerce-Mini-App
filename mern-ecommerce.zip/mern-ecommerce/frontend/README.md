# MERN E-commerce Frontend (starter)
## Setup
1. `npm install`
2. Set REACT_APP_API to your backend URL if not localhost.
3. `npm start`
